<?php 

	header('location: views/Homepage.php');
?>